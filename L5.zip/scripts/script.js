document.body.insertAdjacentHTML('afterbegin', '<h1 class="title">Задание 1</h1>');

const chessBoard = document.querySelector('.board');
const chessSquare = () => {
  let square = '';
  let XY = '';
  for (let y = 8; y >= 1; y--) {
    for (let x = 1; x <= 8; x++) {
      XY = String.fromCharCode(x + 64) + y;
      if (((y % 2 === 0) && (x % 2 === 0)) || ((y % 2 !== 0) && (x % 2 !== 0))) {
        square += '<div class="square black" id="' + XY + '">' + XY + '</div>';
      } else {
        square += '<div class="square yellow" id="' + XY + '">' + XY + '</div>';
      };
    };
  };
  return square;
};

chessBoard.insertAdjacentHTML('beforeend', chessSquare());

// -------------------------------------------------------------------------------------

chessBoard.insertAdjacentHTML('afterend', '<h1 class="title">Задание 2</h1>');

let basket = document.querySelector('.basket');

let products = [];

class Product {
  constructor(name, description, price) {
    this.name = name;
    this.description = description;
    this.price = price;
  };
};

 const prodPush = (name, desc, price) => {
  products.push (new Product (name, desc, price));
  // let prodContent = "";
  // for (let i = 0; i < products.length; i++) {
  //   prodContent += `<p>Название товара: ${products[i].name}</p>
  //     <p>Краткое описание: ${products[i].description}</p>
  //     <p>Цена: ${products[i].price}</p>
  //   `;
  // }
  
  // basket.insertAdjacentHTML('beforeend', prodContent);
};

basket.insertAdjacentHTML('afterend', '<input class="inputField" id="prodName" type="text" placeholder="Введите название товара" value="">');
let prodName = document.querySelector ('#prodName');

prodName.insertAdjacentHTML('afterend', '<input class="inputField" id="prodDesc" type="text" placeholder="Введите краткое описание товара" value="">');
let prodDesc = document.querySelector ('#prodDesc');

prodDesc.insertAdjacentHTML('afterend', '<input class="inputField" id="prodPrice" type="number" placeholder="Введите цену товара" value="">');
let prodPrice = document.querySelector ('#prodPrice');

prodPrice.insertAdjacentHTML('afterend', '<button class="btn" id="btnPush">Добавить товар</button>');
let btnPush = document.querySelector('#btnPush');

btnPush.insertAdjacentHTML('afterend', '<button class="btn" id="btnPop">Удалить товар</button>');
let btnPop = document.querySelector('#btnPop');

btnPush.addEventListener ('click', () => {prodPush (prodName.nodeValue, prodDesc.nodeValue, prodPrice.nodeValue); console.log (products);}, false);
btnPop.addEventListener ('click', () => {console.log ("Удалить...")}, false);
