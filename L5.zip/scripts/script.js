document.body.insertAdjacentHTML('afterbegin', '<h1 class="title">Задание 1</h1>');

const chessBoard = document.querySelector('.board'); // Получаем ссылку на блок доски
const chessSquare = () => {
  let square = ''; // Переменная для всех клеток доски
  let XY = ''; // Переменная для надписей в клетках
  for (let y = 8; y >= 1; y--) { // Цикл для создания строк
    for (let x = 1; x <= 8; x++) { // Цикл для создания столбцов 
      XY = String.fromCharCode(x + 64) + y; // Создание надписи в клетках
      if (((y % 2 === 0) && (x % 2 === 0)) || ((y % 2 !== 0) && (x % 2 !== 0))) { // Если  X и Y чётные либо X и Y нечётные 
        square += '<div class="square black" id="' + XY + '">' + XY + '</div>'; // выводим тёмные клетки
      } else {
        square += '<div class="square yellow" id="' + XY + '">' + XY + '</div>'; // иначе выводим светлые клетки
      };
    };
  };
  return square; // Возвращаем данные по всем клеткам в виде строки
};

chessBoard.insertAdjacentHTML('beforeend', chessSquare()); // Вызываем функцию и вставляем данные в блок доски

// -------------------------------------------------------------------------------------

chessBoard.insertAdjacentHTML('afterend', '<h1 class="title">Задание 2 + Задание 3</h1>');
let basket = document.querySelector('.basket'); // Получаем ссылку на блок карзины
let products = []; // Объявляем пустой массив для карзины

basket.textContent = 'Корзина пуста';

// Объявляем класс для объектов карзины
class Product {
  constructor(nameProd, descriptionProd, priceProd) {
    this.nameProd = nameProd;
    this.descriptionProd = descriptionProd;
    this.priceProd = priceProd;
  };
};

basket.insertAdjacentHTML('afterend',
  `<span class="infoField" id="infoString">В корзине: 0 товар(а)(ов) на сумму 0 руб.</span>`); // Создаём инф. строку
let infoString = document.querySelector('#infoString'); // Получаем ссылку на инф. строку

infoString.insertAdjacentHTML('afterend',
  '<input class="inputField" id="prodName" type="text" placeholder="Введите название товара">'); // Создаём поле ввода названия товара
let prodName = document.querySelector('#prodName'); // Получаем ссылку на поле ввода названия товара

prodName.insertAdjacentHTML('afterend',
  '<input class="inputField" id="prodDesc" type="text" placeholder="Введите краткое описание товара">'); // Создаём поле ввода описания товара
let prodDesc = document.querySelector('#prodDesc'); // Получаем ссылку на поле ввода описания товара

prodDesc.insertAdjacentHTML('afterend',
  '<input class="inputField" id="prodPrice" type="number" placeholder="Введите цену товара">'); // Создаём поле ввода цены товара
let prodPrice = document.querySelector('#prodPrice'); // Получаем ссылку на поле ввода цены товара

prodPrice.insertAdjacentHTML('afterend',
  '<button class="btn" id="btnPush">Добавить товар</button>'); // Создаём кнопку добавления товара
let btnPush = document.querySelector('#btnPush'); // Получаем ссылку на кнопку добавления товара

btnPush.insertAdjacentHTML('afterend',
  '<button class="btn" id="btnPop">Удалить товар</button>');  // Создаём кнопку удаления товара
let btnPop = document.querySelector('#btnPop'); // Получаем ссылку на кнопку удаления товара

btnPush.addEventListener('click', prodPush); // Привязываем событие для кнопки добавления товара
btnPop.addEventListener('click', prodPop); // Привязываем событие для кнопки удаления товара

// Функция добавления товара в корзину
function prodPush() {
  products.push(new Product(prodName.value, prodDesc.value, prodPrice.value));
  viewProd(products);
  countBasketPrice(products);
  clearFields();
};

// Функция удаления товара из корзины
function prodPop() {
  products.pop();
  viewProd(products);
  countBasketPrice(products);
  clearFields();
};

// Функция подсчёта количества и суммы товаров в корзине
function countBasketPrice(arrProduct) {
  let sum = 0;
  for (let i = 0; i < arrProduct.length; i++) {
    sum += parseFloat(arrProduct[i].priceProd);
  }
  infoString.textContent = `В корзине: ${arrProduct.length} товар(а)(ов) на сумму ${sum} руб.`;
};

// Функция вывода информации о товарах в корзине
function viewProd(arrProduct) {
  basket.textContent = '';
  let prodContent = "";

  if (arrProduct.length === 0) {
    basket.textContent = 'Корзина пуста';
  };

  for (let i = 0; i < arrProduct.length; i++) {
    prodContent += `<span class="basket-text">Название товара: ${arrProduct[i].nameProd}</span>
      <span class="basket-text">Краткое описание: ${arrProduct[i].descriptionProd}</span>
      <span class="basket-text">Цена: ${arrProduct[i].priceProd}</span>
      <span class="basket-text">----------------------------</span>
    `;
  };

  console.log(arrProduct);
  basket.insertAdjacentHTML('beforeend', prodContent);
};

// Функция очищения полей ввода
function clearFields() {
  prodName.value = '';
  prodDesc.value = '';
  prodPrice.value = '';
};